"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ModeToggle } from "@/components/mode-toggle"

export function MainNav() {
  const pathname = usePathname()

  return (
    <header className="bg-background border-b">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold text-primary">
          CampusHelp
        </Link>
        <nav className="flex items-center space-x-4">
          <Link
            href="/dashboard"
            className={pathname === "/dashboard" ? "text-primary" : "text-muted-foreground hover:text-primary"}
          >
            Dashboard
          </Link>
          <Link
            href="/tickets"
            className={pathname === "/tickets" ? "text-primary" : "text-muted-foreground hover:text-primary"}
          >
            Tickets
          </Link>
          <Link
            href="/leaderboard"
            className={pathname === "/leaderboard" ? "text-primary" : "text-muted-foreground hover:text-primary"}
          >
            Leaderboard
          </Link>
          <ModeToggle />
          <Button variant="outline" asChild>
            <Link href="/login">Login</Link>
          </Button>
          <Button asChild>
            <Link href="/signup">Sign Up</Link>
          </Button>
        </nav>
      </div>
    </header>
  )
}

