"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ChevronRight, Code, HelpCircle, Trophy } from "lucide-react"

export default function Home() {
  const [currentTestimonial, setCurrentTestimonial] = useState(0)
  const testimonials = [
    { name: "Alice Johnson", text: "CampusHelp saved my project! I got quick help with a coding issue." },
    { name: "Bob Smith", text: "The community here is amazing. I've learned so much by helping others." },
    { name: "Charlie Brown", text: "Earning certificates for helping out is a great motivation. It's a win-win!" },
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [])

  return (
    <div className="flex flex-col min-h-screen">
      <section className="bg-gradient-to-r from-primary to-purple-600 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <motion.h1
            className="text-5xl font-bold mb-6"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Welcome to CampusHelp
          </motion.h1>
          <motion.p
            className="text-xl mb-8"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Your peer-to-peer support system for campus technical issues
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Button size="lg" asChild>
              <Link href="/signup">
                Get Started <ChevronRight className="ml-2" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </section>

      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <Code className="w-12 h-12 mb-4 text-primary" />,
                title: "Create Tickets",
                description: "Easily create tickets for your technical issues and get help from your peers.",
              },
              {
                icon: <HelpCircle className="w-12 h-12 mb-4 text-primary" />,
                title: "Solve Problems",
                description: "Help your fellow students by solving their technical issues and earn rewards.",
              },
              {
                icon: <Trophy className="w-12 h-12 mb-4 text-primary" />,
                title: "Earn Certificates",
                description: "Get recognized for your contributions with yearly certificates to boost your resume.",
              },
            ].map((feature, index) => (
              <motion.div
                key={index}
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
              >
                {feature.icon}
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p>{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-secondary">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">What Our Users Say</h2>
          <div className="max-w-2xl mx-auto">
            <Card>
              <CardContent className="p-6">
                <motion.div
                  key={currentTestimonial}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <p className="text-lg mb-4">&ldquo;{testimonials[currentTestimonial].text}&rdquo;</p>
                  <p className="font-semibold">- {testimonials[currentTestimonial].name}</p>
                </motion.div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}

