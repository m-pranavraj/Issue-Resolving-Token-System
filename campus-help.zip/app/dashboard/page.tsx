"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

const data = [
  { name: "Mon", tickets: 4 },
  { name: "Tue", tickets: 3 },
  { name: "Wed", tickets: 2 },
  { name: "Thu", tickets: 6 },
  { name: "Fri", tickets: 8 },
  { name: "Sat", tickets: 5 },
  { name: "Sun", tickets: 3 },
]

export default function Dashboard() {
  const [activeTickets, setActiveTickets] = useState(5)
  const [solvedTickets, setSolvedTickets] = useState(23)
  const [points, setPoints] = useState(150)

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Dashboard</h1>
      <div className="grid md:grid-cols-3 gap-6 mb-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Tickets</CardTitle>
              <Badge>{activeTickets}</Badge>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{activeTickets}</div>
              <p className="text-xs text-muted-foreground">+2 from last week</p>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Solved Tickets</CardTitle>
              <Badge variant="secondary">{solvedTickets}</Badge>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{solvedTickets}</div>
              <p className="text-xs text-muted-foreground">+5 from last week</p>
            </CardContent>
          </Card>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Points</CardTitle>
              <Badge variant="outline">{points}</Badge>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{points}</div>
              <p className="text-xs text-muted-foreground">+23 from last week</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Weekly Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="tickets" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </motion.div>
      <div className="flex justify-center">
        <Button size="lg" asChild>
          <a href="/tickets/new">Create New Ticket</a>
        </Button>
      </div>
    </div>
  )
}

