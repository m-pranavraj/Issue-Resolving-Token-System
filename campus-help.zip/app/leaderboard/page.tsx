"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

const leaderboardData = [
  { id: 1, name: "Alice Johnson", points: 1250, avatar: "/placeholder.svg?height=40&width=40" },
  { id: 2, name: "Bob Smith", points: 1100, avatar: "/placeholder.svg?height=40&width=40" },
  { id: 3, name: "Charlie Brown", points: 950, avatar: "/placeholder.svg?height=40&width=40" },
  { id: 4, name: "Diana Prince", points: 900, avatar: "/placeholder.svg?height=40&width=40" },
  { id: 5, name: "Ethan Hunt", points: 850, avatar: "/placeholder.svg?height=40&width=40" },
]

export default function Leaderboard() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-center">Leaderboard</h1>
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Top Contributors</CardTitle>
        </CardHeader>
        <CardContent>
          {leaderboardData.map((user, index) => (
            <motion.div
              key={user.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="flex items-center justify-between py-4 border-b last:border-b-0"
            >
              <div className="flex items-center space-x-4">
                <span className="font-bold text-lg w-8">{index + 1}</span>
                <Avatar>
                  <AvatarImage src={user.avatar} alt={user.name} />
                  <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <span className="font-medium">{user.name}</span>
              </div>
              <Badge variant="secondary" className="text-lg">
                {user.points} pts
              </Badge>
            </motion.div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}

